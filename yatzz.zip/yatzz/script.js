/* Discord copy */
try{
  var dc=document.getElementById('dc'),dcs=document.getElementById('dcs');
  dc.addEventListener('click',function(){
    var done=function(m){dcs.textContent=m;setTimeout(function(){dcs.textContent='salin'},1800)};
    try{navigator.clipboard.writeText('fayat0556').then(function(){done('tersalin!')},function(){done('fayat0556')})}catch(e){done('fayat0556')}
  });
}catch(e){}

/* Intro petir */
(function(){
  var o=document.getElementById('intro');
  if(!o)return;
  var reduce=false;
  try{reduce=window.matchMedia('(prefers-reduced-motion: reduce)').matches}catch(e){}
  if(reduce){o.style.display='none';return}
  var started=false;

  function thunder(){
    try{
      var AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;
      var c=new AC();if(c.resume)c.resume();
      var sr=c.sampleRate,t0=c.currentTime+0.55;
      var comp=c.createDynamicsCompressor(),master=c.createGain();
      master.gain.value=0.9;master.connect(comp);comp.connect(c.destination);
      var noise=function(sec,brown){
        var b=c.createBuffer(1,Math.floor(sr*sec),sr),d=b.getChannelData(0),l=0;
        for(var i=0;i<d.length;i++){var w=Math.random()*2-1;if(brown){l=(l+0.02*w)/1.02;d[i]=l*3.5}else{d[i]=w}}
        return b;
      };
      var cs=c.createBufferSource();cs.buffer=noise(0.5,false);
      var hp=c.createBiquadFilter();hp.type='highpass';hp.frequency.value=900;
      var cg=c.createGain();cg.gain.setValueAtTime(0,t0);cg.gain.linearRampToValueAtTime(1,t0+0.005);cg.gain.exponentialRampToValueAtTime(0.001,t0+0.35);
      cs.connect(hp);hp.connect(cg);cg.connect(master);cs.start(t0);
      var rs=c.createBufferSource();rs.buffer=noise(6,true);
      var lp=c.createBiquadFilter();lp.type='lowpass';lp.frequency.setValueAtTime(1400,t0);lp.frequency.exponentialRampToValueAtTime(110,t0+4.5);
      var rg=c.createGain();
      rg.gain.setValueAtTime(0,t0);rg.gain.linearRampToValueAtTime(1.6,t0+0.08);
      rg.gain.linearRampToValueAtTime(0.7,t0+0.7);rg.gain.linearRampToValueAtTime(1.3,t0+1.3);
      rg.gain.linearRampToValueAtTime(0.5,t0+2.1);rg.gain.linearRampToValueAtTime(0.9,t0+2.7);
      rg.gain.linearRampToValueAtTime(0,t0+5.5);
      rs.connect(lp);lp.connect(rg);rg.connect(master);rs.start(t0);
      var os=c.createOscillator();os.type='sine';os.frequency.setValueAtTime(55,t0);os.frequency.linearRampToValueAtTime(28,t0+3);
      var og=c.createGain();og.gain.setValueAtTime(0,t0);og.gain.linearRampToValueAtTime(0.5,t0+0.1);og.gain.linearRampToValueAtTime(0,t0+3.2);
      os.connect(og);og.connect(master);os.start(t0);os.stop(t0+3.3);
      setTimeout(function(){try{c.close()}catch(e){}},7500);
    }catch(e){}
  }

  function enter(){
    if(started)return;started=true;
    thunder();
    try{
      var d=document.getElementById('debris'),cols=['#8A6A4A','#6B4A2F','#A98763','#4A3422'];
      for(var k=0;k<28;k++){
        var s=document.createElement('span'),sz=4+Math.random()*10;
        s.style.cssText='left:'+(26+Math.random()*48)+'%;width:'+sz+'px;height:'+(sz*(0.6+Math.random()*0.6))+'px;background:'+cols[k%4]+';--x:'+((Math.random()-0.5)*280)+'px;--h:'+(160+Math.random()*340)+'px;--r:'+((Math.random()-0.5)*720)+'deg;animation-delay:'+(0.55+Math.random()*0.15)+'s';
        d.appendChild(s);
      }
      if(navigator.vibrate)setTimeout(function(){navigator.vibrate([70,40,140,40,220])},550);
    }catch(e){}
    o.classList.add('hit');
    setTimeout(function(){o.classList.add('out')},2400);
    setTimeout(function(){o.style.display='none'},3400);
  }

  o.addEventListener('click',enter);
  document.addEventListener('keydown',function(e){if(e.key==='Escape'||e.key==='Enter')enter()});
  setTimeout(enter,12000); /* kalau nggak diketuk, intro jalan sendiri tanpa suara */

  /* ketikan tagline */
  try{
    var el=document.getElementById('typed'),full='Code. Break. Learn.',i=0;
    el.textContent='';
    (function t(){el.textContent=full.slice(0,++i);if(i<full.length)setTimeout(t,90)})();
  }catch(e){}
})();

/* ===== Login & Daftar (Firebase Auth + Firestore) ===== */
(function(){
  var $=function(id){return document.getElementById(id)};
  var dlg=$('auth'),logo=$('logo'),chip=$('chip'),msg=$('amsg');
  if(!dlg||!logo)return;
  var mode='login',fb=null,ready=null;

  function say(t,k){msg.textContent=t||'';msg.className='amsg'+(k?' '+k:'')}
  function openDlg(){try{dlg.showModal()}catch(e){dlg.setAttribute('open','')}}
  function closeDlg(){try{dlg.close()}catch(e){dlg.removeAttribute('open')}}

  function setMode(m){
    mode=m;var reg=m==='reg';
    $('tLogin').setAttribute('aria-selected',String(!reg));
    $('tReg').setAttribute('aria-selected',String(reg));
    $('atitle').textContent=reg?'Daftar akun baru':'Masuk ke markas';
    $('gtxt').textContent=reg?'Daftar dengan Google':'Login dengan Google';
    $('sub').textContent=reg?'Daftar':'Login';
    $('fname').hidden=!reg;
    $('ipass').setAttribute('autocomplete',reg?'new-password':'current-password');
    say('');
  }

  function render(u){
    var on=!!u;
    $('pAuth').hidden=on;$('pUser').hidden=!on;chip.hidden=!on;
    if(on){
      var nm=u.displayName||(u.email||'').split('@')[0]||'User';
      $('uname').textContent=nm;$('umail').textContent=u.email||'';
      var av=$('uava');
      if(u.photoURL){av.src=u.photoURL;av.hidden=false}else{av.hidden=true}
      chip.textContent='● '+nm;
    }
  }

  function init(){
    if(ready)return ready;
    ready=(async function(){
      var cfg=window.FIREBASE_CONFIG;
      if(!cfg||!cfg.apiKey||String(cfg.apiKey).indexOf('ISI')===0)return false;
      try{
        var b='https://www.gstatic.com/firebasejs/10.12.2/';
        var m=await Promise.all([import(b+'firebase-app.js'),import(b+'firebase-auth.js'),import(b+'firebase-firestore.js')]);
        var app=m[0].initializeApp(cfg);
        fb={Au:m[1],Fs:m[2],auth:m[1].getAuth(app),db:m[2].getFirestore(app)};
        fb.Au.onAuthStateChanged(fb.auth,render);
        return true;
      }catch(e){return false}
    })();
    return ready;
  }

  async function saveUser(u,provider,name){
    var ref=fb.Fs.doc(fb.db,'users',u.uid),snap=await fb.Fs.getDoc(ref);
    var data={uid:u.uid,name:name||u.displayName||'',email:u.email||'',photo:u.photoURL||'',provider:provider,lastLogin:fb.Fs.serverTimestamp()};
    if(!snap.exists())data.createdAt=fb.Fs.serverTimestamp();
    await fb.Fs.setDoc(ref,data,{merge:true});
  }

  var ERR={
    'auth/popup-closed-by-user':'Login Google dibatalkan.',
    'auth/popup-blocked':'Popup diblokir browser. Izinkan popup lalu coba lagi.',
    'auth/invalid-credential':'Email atau password salah.',
    'auth/invalid-email':'Format email tidak valid.',
    'auth/email-already-in-use':'Email sudah terdaftar. Coba login.',
    'auth/weak-password':'Password minimal 6 karakter.',
    'auth/too-many-requests':'Terlalu banyak percobaan. Coba lagi nanti.',
    'auth/unauthorized-domain':'Domain ini belum diizinkan di Firebase (Authorized domains).',
    'permission-denied':'Akses database ditolak. Cek Firestore rules.'
  };
  function fail(e){say(ERR[e&&e.code]||'Terjadi kesalahan. Coba lagi.','err')}

  async function need(){
    var ok=await init();
    if(!ok)say('Login belum aktif di halaman ini. Isi firebase-config.js lalu deploy (lihat README).','err');
    return ok;
  }

  async function google(){
    if(!(await need()))return;
    say('Membuka Google...');
    try{
      var r=await fb.Au.signInWithPopup(fb.auth,new fb.Au.GoogleAuthProvider());
      await saveUser(r.user,'google');
      say(mode==='reg'?'Pendaftaran berhasil!':'Login berhasil!','ok');
      setTimeout(closeDlg,700);
    }catch(e){fail(e)}
  }

  async function email(){
    if(!(await need()))return;
    var em=$('imail').value.trim(),pw=$('ipass').value,nm=$('iname').value.trim();
    if(!em||!pw){say('Isi email dan password dulu.','err');return}
    if(mode==='reg'&&!nm){say('Isi nama dulu.','err');return}
    say('Memproses...');
    try{
      var r;
      if(mode==='reg'){
        r=await fb.Au.createUserWithEmailAndPassword(fb.auth,em,pw);
        await fb.Au.updateProfile(r.user,{displayName:nm});
        render(fb.auth.currentUser);
        await saveUser(r.user,'password',nm);
      }else{
        r=await fb.Au.signInWithEmailAndPassword(fb.auth,em,pw);
        await saveUser(r.user,'password');
      }
      $('ipass').value='';
      say(mode==='reg'?'Pendaftaran berhasil!':'Login berhasil!','ok');
      setTimeout(closeDlg,700);
    }catch(e){fail(e)}
  }

  logo.addEventListener('click',function(){openDlg();init()});
  chip.addEventListener('click',openDlg);
  $('aclose').addEventListener('click',closeDlg);
  dlg.addEventListener('click',function(e){if(e.target===dlg)closeDlg()});
  $('tLogin').addEventListener('click',function(){setMode('login')});
  $('tReg').addEventListener('click',function(){setMode('reg')});
  $('gbtn').addEventListener('click',google);
  $('sub').addEventListener('click',email);
  ['iname','imail','ipass'].forEach(function(id){$(id).addEventListener('keydown',function(e){if(e.key==='Enter')email()})});
  $('lout').addEventListener('click',async function(){try{await fb.Au.signOut(fb.auth);closeDlg()}catch(e){}});
  setMode('login');
  init(); /* pulihkan sesi login yang tersimpan */
})();
