# уαтzz — setup login Google + database

File: index.html, style.css, script.js, firebase-config.js

## 1. Bikin project Firebase (gratis)
1. Buka https://console.firebase.google.com, klik Add project.
2. Build > Authentication > Get started > Sign-in method: aktifkan **Google** dan **Email/Password**.
3. Build > Firestore Database > Create database (mode production).
4. Tab Rules, ganti isinya dengan ini lalu Publish:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{uid} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```
Artinya tiap user cuma bisa baca dan tulis datanya sendiri.

## 2. Ambil config
Project settings > Your apps > Web (</>) > salin config, tempel ke firebase-config.js.

## 3. Deploy
Upload folder ini ke Vercel, Netlify, GitHub Pages, atau Firebase Hosting.
Lalu di Authentication > Settings > **Authorized domains**, tambahkan domain web lo.
(Login nggak jalan kalau dibuka langsung dari file di HP/laptop, harus lewat domain hosting atau localhost.)

## Data yang disimpan (koleksi `users/{uid}`)
uid, name, email, photo, provider (google/password), createdAt, lastLogin.
Password TIDAK disimpan di database lo, diurus Firebase Auth.
Lihat datanya di Firebase Console > Firestore Database.
