const firebaseConfig = {
  apiKey: "AIzaSy...",
  authDomain: "project-lu.firebaseapp.com",
  projectId: "project-lu",
  storageBucket: "project-lu.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef"
};